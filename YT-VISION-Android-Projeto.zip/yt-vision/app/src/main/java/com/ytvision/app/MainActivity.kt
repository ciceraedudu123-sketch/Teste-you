package com.ytvision.app

import android.os.Bundle
import android.content.Context
import android.net.Uri
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

private val Bg = Color(0xFF101014)
private val Panel = Color(0xFF1B1B22)
private val Accent = Color(0xFFFF3155)
private val Txt = Color(0xFFF5F5F7)
private val Muted = Color(0xFFAAAAB5)

data class Video(val id: String, val title: String, val channel: String, val thumbnail: String, val source: String, val url: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VisionApp() }
    }
}

@Composable
fun VisionApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("ytvision", Context.MODE_PRIVATE) }
    var tab by remember { mutableStateOf("Início") }
    var query by remember { mutableStateOf("") }
    var videos by remember { mutableStateOf(listOf(
        Video("demo1", "Bem-vindo ao YT VISION", "YT VISION", "", "local", "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"),
        Video("demo2", "Vídeo de demonstração", "Catálogo independente", "", "local", "https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4")
    )) }
    var selected by remember { mutableStateOf<Video?>(null) }
    var searchResults by remember { mutableStateOf<List<Video>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var addUrl by remember { mutableStateOf("") }
    var addTitle by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val favorites = remember { mutableStateListOf<String>().apply { addAll(prefs.getStringSet("favorites", emptySet()) ?: emptySet()) } }
    val history = remember { mutableStateListOf<String>() }

    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Panel, onBackground = Txt, onSurface = Txt)) {
        Column(Modifier.fillMaxSize().background(Bg)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("YT", color = Accent, fontSize = 25.sp, fontWeight = FontWeight.Black)
                Text(" VISION", color = Txt, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.weight(1f))
                Icon(Icons.Default.AccountCircle, contentDescription = "Perfil", tint = Muted)
            }
            if (selected != null) {
                PlayerScreen(video = selected!!, onBack = { selected = null })
            } else {
                when (tab) {
                    "Buscar" -> SearchScreen(query, { query = it }, searchResults, loading, message, onSearch = {
                        if (query.isNotBlank()) scope.launch {
                            loading = true; message = ""
                            val result = searchYouTube(query)
                            searchResults = result.first
                            message = result.second
                            loading = false
                        }
                    }, onPlay = { selected = it })
                    "Adicionar" -> AddScreen(addTitle, { addTitle = it }, addUrl, { addUrl = it }, onAdd = {
                        val uri = runCatching { Uri.parse(addUrl.trim()) }.getOrNull()
                        if (uri != null && uri.scheme in listOf("https", "http") && uri.host != null && addTitle.isNotBlank()) {
                            val v = Video("custom_${System.currentTimeMillis()}", addTitle.trim(), "Minha biblioteca", "", "local", addUrl.trim())
                            videos = listOf(v) + videos
                            message = "Vídeo adicionado à biblioteca."
                            addTitle = ""; addUrl = ""
                        } else message = "Informe um título e uma URL http/https válida."
                    }, message)
                    "Favoritos" -> VideoList("Seus favoritos", videos.filter { favorites.contains(it.id) }, favorites, onFavorite = { toggleFavorite(it, favorites, prefs) }, onPlay = { selected = it })
                    "Histórico" -> VideoList("Assistidos recentemente", videos.filter { history.contains(it.id) }, favorites, onFavorite = { toggleFavorite(it, favorites, prefs) }, onPlay = { selected = it })
                    "Configurações" -> SettingsScreen()
                    else -> VideoList("Descubra vídeos", videos, favorites, onFavorite = { toggleFavorite(it, favorites, prefs) }, onPlay = { selected = it; history.remove(it.id); history.add(0, it.id) })
                }
            }
            Spacer(Modifier.weight(1f, fill = false))
            NavigationBar(containerColor = Color(0xFF17171D)) {
                listOf("Início" to Icons.Default.Home, "Buscar" to Icons.Default.Search, "Adicionar" to Icons.Default.AddCircle, "Favoritos" to Icons.Default.Favorite, "Histórico" to Icons.Default.History).forEach { (name, icon) ->
                    NavigationBarItem(selected = tab == name, onClick = { tab = name; selected = null }, icon = { Icon(icon, null) }, label = { Text(name, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Accent, selectedTextColor = Accent, indicatorColor = Color(0xFF38202A), unselectedIconColor = Muted, unselectedTextColor = Muted))
                }
            }
        }
    }
}

@Composable
fun VideoList(title: String, list: List<Video>, favorites: List<String>, onFavorite: (Video) -> Unit, onPlay: (Video) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Text(title, color = Txt, fontSize = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp))
        if (list.isEmpty()) Text("Nada por aqui ainda.", color = Muted, modifier = Modifier.padding(20.dp))
        LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            items(list, key = { it.id }) { video ->
                Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).clickable { onPlay(video) }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(width = 126.dp, height = 76.dp).background(Color(0xFF30303A), RoundedCornerShape(9.dp)), contentAlignment = Alignment.Center) {
                        Icon(if (video.source == "youtube") Icons.Default.PlayCircle else Icons.Default.VideoLibrary, null, tint = Accent, modifier = Modifier.size(34.dp))
                    }
                    Column(Modifier.weight(1f).padding(start = 12.dp)) {
                        Text(video.title, color = Txt, fontWeight = FontWeight.SemiBold, maxLines = 2)
                        Text(video.channel, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp))
                        Text(if (video.source == "youtube") "YouTube" else "Independente", color = Accent, fontSize = 10.sp)
                    }
                    IconButton(onClick = { onFavorite(video) }) { Icon(Icons.Default.Favorite, null, tint = if (favorites.contains(video.id)) Accent else Muted) }
                }
            }
        }
    }
}

@Composable
fun SearchScreen(query: String, onQuery: (String) -> Unit, results: List<Video>, loading: Boolean, message: String, onSearch: () -> Unit, onPlay: (Video) -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Pesquisar no YouTube", color = Txt, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth().padding(top = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = query, onValueChange = onQuery, modifier = Modifier.weight(1f), singleLine = true, label = { Text("O que você quer assistir?") })
            IconButton(onClick = onSearch) { Icon(Icons.Default.Search, null, tint = Accent) }
        }
        if (loading) CircularProgressIndicator(color = Accent, modifier = Modifier.padding(18.dp))
        if (message.isNotBlank()) Text(message, color = Muted, modifier = Modifier.padding(top = 10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(top = 14.dp)) {
            items(results, key = { it.id }) { v ->
                Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).clickable { onPlay(v) }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.PlayCircle, null, tint = Accent, modifier = Modifier.size(42.dp))
                    Column(Modifier.padding(start = 12.dp)) { Text(v.title, color = Txt, fontWeight = FontWeight.SemiBold); Text(v.channel, color = Muted, fontSize = 12.sp) }
                }
            }
        }
    }
}

@Composable
fun AddScreen(title: String, onTitle: (String) -> Unit, url: String, onUrl: (String) -> Unit, onAdd: () -> Unit, message: String) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Adicionar vídeo independente", color = Txt, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Text("Adicione uma URL direta de vídeo MP4 ou outro formato compatível com o player. Use apenas conteúdo que você tenha direito de acessar.", color = Muted)
        OutlinedTextField(value = title, onValueChange = onTitle, label = { Text("Título do vídeo") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = url, onValueChange = onUrl, label = { Text("URL HTTPS do vídeo") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = onAdd, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Text("Adicionar à biblioteca") }
        if (message.isNotBlank()) Text(message, color = Muted)
    }
}

@Composable
fun PlayerScreen(video: Video, onBack: () -> Unit) {
    val context = LocalContext.current
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Txt) }
            Text(video.title, color = Txt, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
        if (video.source == "youtube" || video.url.contains("youtube.com") || video.url.contains("youtu.be")) {
            val id = video.id.removePrefix("yt_")
            AndroidView(factory = { ctx -> WebView(ctx).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                webViewClient = WebViewClient()
                loadUrl("https://www.youtube.com/embed/$id?playsinline=1&rel=0")
            } }, modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f))
            Text("Reprodução pelo player oficial incorporado do YouTube. Anúncios e restrições da plataforma podem ser aplicados.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(14.dp))
        } else {
            val player = remember(video.url) { ExoPlayer.Builder(context).build().apply { setMediaItem(MediaItem.fromUri(video.url)); prepare(); playWhenReady = true } }
            DisposableEffect(player) { onDispose { player.release() } }
            AndroidView(factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true } }, modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f))
            Text("Fonte independente", color = Muted, modifier = Modifier.padding(14.dp))
        }
    }
}

@Composable
fun SettingsScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Configurações", color = Txt, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("YT VISION 1.0.0", color = Accent, fontWeight = FontWeight.Bold)
        Text("O aplicativo não insere anúncios próprios. O conteúdo do YouTube é reproduzido pelo player oficial incorporado e pode exibir anúncios.", color = Muted)
        Text("Para ativar pesquisas, configure uma chave da YouTube Data API v3 no arquivo gradle.properties. Nunca publique sua chave em repositórios públicos.", color = Muted)
        Text("Vídeos independentes devem usar URLs diretas autorizadas e compatíveis com reprodução no Android.", color = Muted)
    }
}

fun toggleFavorite(video: Video, favorites: MutableList<String>, prefs: android.content.SharedPreferences) {
    if (favorites.contains(video.id)) favorites.remove(video.id) else favorites.add(video.id)
    prefs.edit().putStringSet("favorites", favorites.toSet()).apply()
}

suspend fun searchYouTube(query: String): Pair<List<Video>, String> = withContext(Dispatchers.IO) {
    val key = BuildConfig.YOUTUBE_API_KEY
    if (key.isBlank()) return@withContext Pair(emptyList(), "Configure sua chave da YouTube Data API v3 para pesquisar. A reprodução por URL independente já funciona.")
    try {
        val url = "https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=20&q=${Uri.encode(query)}&key=$key"
        val request = Request.Builder().url(url).build()
        OkHttpClient().newCall(request).execute().use { response ->
            if (!response.isSuccessful) return@withContext Pair(emptyList(), "Falha na pesquisa (HTTP ${response.code}). Verifique a chave e a cota da API.")
            val json = JSONObject(response.body?.string().orEmpty())
            val items = json.optJSONArray("items") ?: return@withContext Pair(emptyList(), "Nenhum resultado encontrado.")
            val output = mutableListOf<Video>()
            for (i in 0 until items.length()) {
                val item = items.getJSONObject(i); val id = item.getJSONObject("id").optString("videoId")
                val snippet = item.getJSONObject("snippet")
                output.add(Video("yt_$id", snippet.optString("title"), snippet.optString("channelTitle"), snippet.optJSONObject("thumbnails")?.optJSONObject("medium")?.optString("url").orEmpty(), "youtube", "https://www.youtube.com/watch?v=$id"))
            }
            Pair(output, if (output.isEmpty()) "Nenhum vídeo encontrado." else "${output.size} resultados.")
        }
    } catch (e: Exception) { Pair(emptyList(), "Erro de conexão: ${e.localizedMessage ?: "tente novamente"}") }
}
