# YT VISION — Android

Aplicativo pessoal de vídeos com interface própria, pesquisa via YouTube Data API v3 e reprodução por player oficial incorporado; também aceita URLs diretas de vídeos independentes compatíveis com Media3/ExoPlayer.

## Requisitos
- Android Studio (ou build via GitHub Actions)
- JDK 17
- Android SDK 35

## Abrir e compilar
1. Abra a pasta `yt-vision` no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Execute em um aparelho Android 7.0 ou superior.
4. Para gerar APK: `gradle assembleDebug`.

## Ativar pesquisa do YouTube
1. Crie um projeto no Google Cloud Console.
2. Ative **YouTube Data API v3** e gere uma chave de API.
3. Adicione `YOUTUBE_API_KEY=SUA_CHAVE` ao `gradle.properties` (não compartilhe essa chave publicamente).
4. Sincronize e compile novamente.

A pesquisa usa a API oficial. A reprodução usa o player incorporado do YouTube, sujeito aos termos, anúncios, disponibilidade e restrições da plataforma. O app não bloqueia anúncios do YouTube.

## Vídeos independentes
Na aba **Adicionar**, informe um título e uma URL direta HTTPS para um arquivo de vídeo que você tenha direito de reproduzir. Links de páginas de streaming não são necessariamente URLs diretas de mídia.

## Limitações desta versão 1.0
- Favoritos ficam salvos localmente; histórico fica em memória durante a sessão.
- A biblioteca independente é mantida em memória nesta versão.
- A pesquisa do YouTube requer chave da API e está sujeita à cota do Google.
- Não há login, sincronização em nuvem, downloads ou reprodução em segundo plano.

## Build no GitHub sem Android Studio
Envie o projeto para um repositório GitHub. Acesse **Actions → Build Android APK → Run workflow**. O APK de depuração será publicado como artefato do workflow.
